<?php
include('init.php');
session_start();

// Assuming you're using 'userid' as the session variable
$login_user = $_SESSION['login_user']; // Corrected variable name

// Check if the user is logged in
if (!isset($login_user)) {
    header("Location: login.php");
    exit; // Make sure to exit after redirect
}

// Perform additional checks or queries if needed
// ...
?>

