<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Classes</title>
    <link rel="stylesheet" href="css/home.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" type='text/css' href="css/manage.css">
    <style>
        
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
        }
        
        .title {
            background-color: #007bff;
            color: white;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .title img {
            height: 40px;
        }
        
        .heading {
            font-size: 24px;
            margin: 0;
        }
        
        .nav {
            background-color: #333;
            overflow: hidden;
        }
        
        .nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }
        
        .nav li {
            float: left;
        }
        
        .nav a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
        }
        
        .nav a:hover {
            background-color: #ddd;
            color: black;
        }
        
        .main {
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            font-size: 24px;
            margin-bottom: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table, th, td {
            border: 1px solid #ddd;
        }
        
        th, td {
            padding: 10px;
            text-align: left;
        }
        
        caption {
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        form {
            margin-bottom: 20px;
        }
        
        input[type="text"] {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 60%;
        }
        
        button[type="submit"] {
            padding: 8px 12px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        button[type="submit"]:hover {
            background-color: #0056b3;
        }
        
        a {
            color: #007bff;
            text-decoration: none;
        }
        
        a:hover {
            text-decoration: underline;
        }
        
        
    </style>
    <title>
        delete class
    </title>
</head>
<body>
<div>
<a href="dashboard.php"><img src="images/logo.jpg" alt="Logo"class="logo"></a>  
<h1 align="center">
        IMPERIAL INTERNATIONAL COLLEGE IBADAN
        </h1>
           </div>

    <div class="nav">
        <ul>
            <li class="dropdown" onclick="toggleDisplay('1')">
                <a href="" class="dropbtn">Classes &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="1">
                    <a href="add_classes.php">Add Class</a>
                    <a href="manage_classes.php">Manage Class</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('2')">
                <a href="#" class="dropbtn">Students &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="2">
                    <a href="add_students.php">Add Students</a>
                    <a href="manage_students.php">Manage Students</a>
                </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('3')">
                <a href="#" class="dropbtn">Results &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="3">
                <a href="add_CA.php">Add C.A Test</a>
                <a href="add_assignment.php">Add Assignment</a>
                <a href="add_Examination.php">Add Examination</a>
                <a href="manage_caresults.php">Manage CA_Results</a>
                <a href="manage_assignmentresults.php">Manage Assignment_Results</a>
                <a href="manage_examninationresults.php">Manage examination_Results</a>
            </div>
            </li>
            <li class="dropdown" onclick="toggleDisplay('2')">
                <a href="#" class="dropbtn">Subject &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="2">
                <a href="add_subject.php">Add Subject</a>
                <a href="manage_subjects.php">Manage subject</a>
            </div>
            </li>

            <li class="dropdown" onclick="toggleDisplay('2')">
                <a href="#" class="dropbtn">Manager User &nbsp
                    <span class="fa fa-angle-down"></span>
                </a>
                <div class="dropdown-content" id="2">
                <a href="manageadmin.php">Manage User</a>
                    <a href="logout.php">Logout</a>
                </div>
            </li>
        </ul>
    </div>

    <div class="main">
        <h1>Manage Classes</h1>

       
        <form method="GET">
            <input type="text" name="search" placeholder="Search by class name">
            <button type="submit"><i class="fa fa-search"></i> Search</button>
        </form>

        <?php
        include('init.php');
        include('session.php');
        $db = mysqli_select_db($conn, 'srms');

       
        if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['delete'])) {
            $class_id = $_GET['delete'];

            
            $class_id = mysqli_real_escape_string($conn, $class_id);

            $deleteQuery = "DELETE FROM class WHERE id = $class_id";
            mysqli_query($conn, $deleteQuery);
        }

        
        if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
            $class_id = $_GET['id'];

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $newClassName = $_POST['newClassName'];

                
                $class_id = mysqli_real_escape_string($conn, $class_id);
                $newClassName = mysqli_real_escape_string($conn, $newClassName);

                
                $updateQuery = "UPDATE class SET name = '$newClassName' WHERE id = $class_id";
                if (mysqli_query($conn, $updateQuery)) {
                    header("Location: manage_classes.php");
                    exit;
                } else {
                    echo "Error updating class: " . mysqli_error($conn);
                }
            }

            
            $selectQuery = "SELECT name FROM class WHERE id = $class_id";
            $result = mysqli_query($conn, $selectQuery);
            $row = mysqli_fetch_assoc($result);
            $className = $row['name'];
        }

        $sql = "SELECT `name`, `id` FROM `class`";

        
        if (isset($_GET['search'])) {
            $searchTerm = $_GET['search'];

            
            $searchTerm = mysqli_real_escape_string($conn, $searchTerm);

            $sql .= " WHERE `name` LIKE '%$searchTerm%'";
        }

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            echo "<table>
                <caption>Manage Classes</caption>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>";

            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                echo "<td><a href='edit_class.php?id=" . htmlspecialchars($row['id']) . "'>Edit</a></td>";
                echo "<td><a href='manage_classes.php?delete=" . htmlspecialchars($row['id']) . "' onclick='return confirm(\"Are you sure?\")'>Delete</a></td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "No results found.";
        }
        ?>
    </div>
</body>
</html>
