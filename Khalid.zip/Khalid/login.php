<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="./font-awesome-4.7.0/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <title>
        login
    </title>
    <style>
        
        body {
            background-color: rgb(0, 128, 66);
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        .title {
            font-size: 28px;
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }

        .login-form {
            text-align: center;
        }

        .login-form fieldset {
            border: none;
        }

        .login-form legend {
            font-size: 20px;
            font-weight: bold;
        }

        .login-form input[type="text"],
        .login-form input[type="password"],
        .login-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .login-form input[type="submit"] {
            background-color: #008041;
            color: #fff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-form input[type="submit"]:hover {
            background-color: #006530;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title">
            <span>IMPERIAL INTERNATIONAL COLLEGE</span>
        </div>

        <div class="login-form">
            <form action="" method="post" name="login">
                <fieldset>
                    <legend>Admin Login</legend>
                    <input type="text" name="userid" placeholder="Username" autocomplete="off">
                    <input type="password" name="password" placeholder="Password" autocomplete="off">
                    <input type="submit" value="Login">
                </fieldset>
            </form>    
        </div>
    </div>
</body>
</html>


<?php
    include("init.php");
    session_start();

    if (isset($_POST["userid"],$_POST["password"]))
    {
        $username=$_POST["userid"];
        $password=$_POST["password"];
        $sql = "SELECT userid FROM admin_login WHERE userid='$username' and password = '$password'";
        $result=mysqli_query($conn,$sql);

        $row=mysqli_fetch_array($result);
        $count=mysqli_num_rows($result);
        
        if($count==1) {
            $_SESSION['login_user']=$username;
            header("Location: dashboard.php");
        }else {
            echo '<script language="javascript">';
            echo 'alert("Invalid Username or Password")';
            echo '</script>';
        }
        
    }
    
?>
<?php
if (isset($_POST["Email"],$_POST["password"]))
{
    $Email=$_POST["Email"];
    $password=$_POST["password"];
    $sql = "SELECT Email FROM student WHERE Email='$Email' and password = '$password'";
    $result=mysqli_query($conn,$sql);

    $row=mysqli_fetch_array($result);
    $count=mysqli_num_rows($result);
    
    if($count==1) {
        $_SESSION['login_user']=$Email;
        header("Location: resultdashboard.php");
    }else {
        echo '<script language="javascript">';
        echo 'alert("Invalid Username or Password")';
        echo '</script>';
    }
    
}
?>
