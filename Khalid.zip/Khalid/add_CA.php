<?php

include('init.php');
include('session.php');


$className = '';

if (isset($_POST['registrationNumber'], $_POST['subject'], $_POST['score'],$_POST['term'],$_POST['session'])) {
    $registrationNumber = $_POST['registrationNumber'];
    $subject = $_POST['subject'];
    $score = $_POST['score'];
    $session = $_POST['term'];
    $term = $_POST['session'];

    
    $classQuery = "SELECT className FROM student WHERE registrationNumber = '$registrationNumber'";
    $classResult = mysqli_query($conn, $classQuery);

    if (mysqli_num_rows($classResult) == 1) {
        $row = mysqli_fetch_assoc($classResult);
        $className = $row['className'];

        
        $insertQuery = "INSERT INTO cascore (registrationNumber, subject, score,term,session) VALUES ('$registrationNumber', '$subject', '$score','$term','$session')";
        $insertResult = mysqli_query($conn, $insertQuery);

        if ($insertResult) {
            echo '<script language="javascript">';
            echo 'alert("Score recorded successfully")';
            echo '</script>';
        } else {
            echo '<script language="javascript">';
            echo 'alert("Error: ' . mysqli_error($conn) . '")';
            echo '</script>';
        }
    } else {
        echo '<script language="javascript">';
        echo 'alert("Student not found")';
        echo '</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/form.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <style>
                body {
            background-color: rgb(0, 128, 66);
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
        }

        .logo {
            width: 100px;
            height: auto;
            margin: 10px;
        }

        .title {
            font-size: 28px;
            text-align: center;
            color: #000;
        }

        .nav {
            margin-top: 20px;
            background-color: #333;
            border-radius: 5px;
            overflow: hidden;
        }

        .nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .nav li {
            padding: 10px 20px;
        }

        .nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .nav a:hover {
            color: #00ff00;
        }

        .main {
            margin-top: 20px;
            width: 100%;
        }

        .main form {
            text-align: center;
            margin-bottom: 20px;
        }

        .main input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .main input[type="submit"] {
            background-color: #008041;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .main input[type="submit"]:hover {
            background-color: #006530;
        }

     
        .main legend {
            font-weight: bold;
        }
    </style>
    <title>Record Student Scores</title>
</head>
<body>
<div>
    <a href="dashboard.php"><img src="images/logo.jpg" alt="Logo" class="logo"></a>
    <h1 align="center">IMPERIAL INTERNATIONAL COLLEGE IBADAN</h1>
</div>

<div class="nav">
    <ul>
        <li class="dropdown" onclick="toggleDisplay('1')">
            <a href="" class="dropbtn">Classes &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="1">
                <a href="add_classes.php">Add Class</a>
                <a href="manage_classes.php">Manage Class</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Students &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="add_students.php">Add Students</a>
                <a href="manage_students.php">Manage Students</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('3')">
            <a href="#" class="dropbtn">Results &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="3">
                <a href="add_CA.php">Add C.A Test</a>
                <a href="add_assignment.php">Add Assignment</a>
                <a href="add_Examination.php">Add Examination</a>
                <a href="manage_caresults.php">Manage CA_Results</a>
                <a href="manage_assignmentresults.php">Manage Assignment_Results</a>
                <a href="manage_examninationresults.php">Manage examination_Results</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Subject &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="add_subject.php">Add Subject</a>
                <a href="manage_subjects.php">Manage subject</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Manager User &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="manageadmin.php">Manage User</a>
                <a href="logout.php">Logout</a>
            </div>
        </li>
    </ul>
</div>


<div class="main">
    <form action="" method="post">
        <fieldset>
            <legend>Record Student Score</legend>
           
            <label for="registrationNumber">Select Student by Registration Number:</label>
            <select name="registrationNumber" id="registrationNumber" required>
                <?php
                
                $registrationNumbersQuery = "SELECT registrationNumber, className FROM student";
                $registrationNumbersResult = mysqli_query($conn, $registrationNumbersQuery);
                while ($row = mysqli_fetch_assoc($registrationNumbersResult)) {
                    echo '<option value="' . $row['registrationNumber'] . '" data-class="' . $row['className'] . '">' . $row['registrationNumber'] . '</option>';
                }
                ?>
            </select>

            <label for="subject">Select Subject:</label>
            <select name="subject" id="subject" required>
                <?php
                
                $subjectsQuery = "SELECT subject FROM subject";
                $subjectsResult = mysqli_query($conn, $subjectsQuery);
                while ($row = mysqli_fetch_assoc($subjectsResult)) {
                    echo '<option value="' . $row['subject'] . '">' . $row['subject'] . '</option>';
                }
                ?>
            </select>

            
            <label for="className">Class:</label>
            <input type="text" name="className" id="className" readonly>

            <label for="score">ENTER C.A TEST Score:</label>
            <input type="text" name="score" id="score" required>

            <label for="term">TERM:</label>
            <input type="text" name="term" id="term" required>

            <label for="session">ENTER SESSION:</label>
            <input type="text" name="session" id="session" required>

            

            <input type="submit" value="Record Score">
        </fieldset>
    </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const registrationNumberSelect = document.getElementById("registrationNumber");
    const classNameInput = document.getElementById("className");

    registrationNumberSelect.addEventListener("change", function () {
        // Get the selected registration number's class and update the class field
        const selectedOption = registrationNumberSelect.options[registrationNumberSelect.selectedIndex];
        const selectedClass = selectedOption.getAttribute("data-class");
        classNameInput.value = selectedClass;
    });
});
</script>
</body>
</html>
