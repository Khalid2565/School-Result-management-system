<?php

include('init.php');
            include('session.php');
            ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/form.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <style>
         <style>
      
        body {
            background-color: rgb(0, 128, 66);
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
        }

        .logo {
            width: 100px;
            height: auto;
            margin: 10px;
        }

        .title {
            font-size: 28px;
            text-align: center;
            color: #000;
        }

        .nav {
            margin-top: 20px;
            background-color: #333;
            border-radius: 5px;
            overflow: hidden;
        }

        .nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .nav li {
            padding: 10px 20px;
        }

        .nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .nav a:hover {
            color: #00ff00;
        }

        .main {
            margin-top: 20px;
            width: 100%;
        }

        .main form {
            text-align: center;
            margin-bottom: 20px;
        }

        .main input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .main input[type="submit"] {
            background-color: black;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .main input[type="submit"]:hover {
            background-color: black;
        }

        
        .main legend {
            font-weight: bold;
        }
    </style>
    <title>Add subject</title>
</head>
<body>
<div>
    <a href="dashboard.php"><img src="images/logo.jpg" alt="Logo" class="logo"></a>
    <h1 align="center">IMPERIAL INTERNATIONAL COLLEGE IBADAN</h1>
    </div>

<div class="nav">
    <ul>
        <li class="dropdown" onclick="toggleDisplay('1')">
            <a href="" class="dropbtn">Classes &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="1">
                <a href="add_classes.php">Add Class</a>
                <a href="manage_classes.php">Manage Class</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Students &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="add_students.php">Add Students</a>
                <a href="manage_students.php">Manage Students</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('3')">
            <a href="#" class="dropbtn">Results &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="3">
                <a href="add_CA.php">Add C.A Test</a>
                <a href="add_assignment.php">Add Assignment</a>
                <a href="add_Examination.php">Add Examination</a>
                <a href="manage_caresults.php">Manage CA_Results</a>
                <a href="manage_assignmentresults.php">Manage Assignment_Results</a>
                <a href="manage_examninationresults.php">Manage examination_Results</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Subject &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="add_subject.php">Add Subject</a>
                <a href="manage_subjects.php">Manage subject</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Manager User &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="manageadmin.php">Manage User</a>
                <a href="logout.php">Logout</a>
            </div>
        </li>
    </ul>
</div>
<div class="main">
    <form action="" method="post">
        <fieldset>
            <legend>Add Subject</legend>
            <input type="text" name="subjectCode" placeholder="Subject Code" required>
            <input type="text" name="subject" placeholder="Subject " required>
            <input type="submit" value="Submit">
        </fieldset>
    </form>
</div>

<?php
if (isset($_POST['subjectCode'], $_POST['subject'])) {
    $code = $_POST['subjectCode'];
    $subject = $_POST['subject'];
    

   
    $sql = "INSERT INTO subject (`subjectCode`, `subject`) 
            VALUES ('$code', '$subject')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo '<script language="javascript">';
        echo 'alert("Record inserted successfully")';
        echo '</script>';
    } else {
        echo '<script language="javascript">';
        echo 'alert("Error: ' . mysqli_error($conn) . '")';
        echo '</script>';
    }
}
?>
</body>
</html>

           