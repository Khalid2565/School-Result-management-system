<?php
include('init.php');



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form has been submitted

    // Retrieve the class ID and updated class name from the form
    $class_id = $_POST['id'];
    $updated_class_name = $_POST['updated_class_name'];

    // Sanitize input to prevent SQL injection
    $class_id = mysqli_real_escape_string($conn, $class_id);
    $updated_class_name = mysqli_real_escape_string($conn, $updated_class_name);

    // Update the class name in the database
    $updateQuery = "UPDATE `class` SET `name` = '$updated_class_name' WHERE `id` = '$class_id'";
    
    if (mysqli_query($conn, $updateQuery)) {
        // Class name updated successfully
        header("Location: manage_classes.php"); // Redirect to the class management page
        exit();
    } else {
        // Error updating class name
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} elseif ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    // Display the form for editing the class name

    $class_id = $_GET['id'];

    // Sanitize input to prevent SQL injection
    $class_id = mysqli_real_escape_string($conn, $class_id);

    // Retrieve the current class name from the database
    $selectQuery = "SELECT `name` FROM `class` WHERE `id` = '$class_id'";
    $result = mysqli_query($conn, $selectQuery);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $current_class_name = $row['name'];

        // Display the form for editing the class name
        
        
        
    } else {
        echo "Class not found.";
    }
} else {
    // Invalid request
    echo "Invalid request.";
}

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/home.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="normalize.css">
    <title>Dashboard</title>
    <style>
        /* Common styles for all screen sizes */
        body {
            background-color: rgb(0, 128, 66);
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
        }

        .logo {
            width: 100px;
            height: auto;
            margin: 10px;
        }

        .title {
            font-size: 28px;
            text-align: center;
            color: #000;
        }

        .nav {
            margin-top: 20px;
            background-color: #333;
            border-radius: 5px;
            overflow: hidden;
        }

        .nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .nav li {
            padding: 10px 20px;
        }

        .nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .nav a:hover {
            color: #00ff00;
        }

        .main {
            margin-top: 20px;
            width: 100%;
        }

        .main form {
            text-align: center;
            margin-bottom: 20px;
        }

        .main input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .main input[type="submit"] {
            background-color: #008041;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .main input[type="submit"]:hover {
            background-color: #006530;
        }

      
        .main legend {
            font-weight: bold;
        }
        
    </style>
    <title>
        Edit class
    </title>
</head>
<body>
<div>
    <a href="dashboard.php"><img src="images/logo.jpg" alt="Logo" class="logo"></a>
    <h1 align="center">
        IMPERIAL INTERNATIONAL COLLEGE IBADAN
    </h1>
    </div>

<div class="nav">
    <ul>
        <li class="dropdown" onclick="toggleDisplay('1')">
            <a href="" class="dropbtn">Classes &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="1">
                <a href="add_classes.php">Add Class</a>
                <a href="manage_classes.php">Manage Class</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Students &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="add_students.php">Add Students</a>
                <a href="manage_students.php">Manage Students</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('3')">
            <a href="#" class="dropbtn">Results &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="3">
                <a href="add_CA.php">Add C.A Test</a>
                <a href="add_assignment.php">Add Assignment</a>
                <a href="add_Examination.php">Add Examination</a>
                <a href="manage_caresults.php">Manage CA_Results</a>
                <a href="manage_assignmentresults.php">Manage Assignment_Results</a>
                <a href="manage_examninationresults.php">Manage examination_Results</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Subject &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
                <a href="add_subject.php">Add Subject</a>
                <a href="manage_subjects.php">Manage subject</a>
            </div>
        </li>
        <li class="dropdown" onclick="toggleDisplay('2')">
            <a href="#" class="dropbtn">Manager User &nbsp
                <span class="fa fa-angle-down"></span>
            </a>
            <div class="dropdown-content" id="2">
            <a href="manageadmin.php">Manage User</a>
                    <a href="logout.php">Logout</a>
            </div>
        </li>
    </ul>
</div>
<?php
echo "<form method='POST' action='edit_class.php'>
<div>
        <input type='hidden' name='id' value='$class_id'>
        Current Class Name: $current_class_name<br>
        New Class Name: <input type='text' name='updated_class_name' value='$current_class_name'><br>
        <input type='submit' value='Update'>
    </div>
      </form>";
?>





</body>
</html>
