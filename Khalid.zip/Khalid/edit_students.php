<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Class</title>
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/form.css">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <style>
        /* Common styles for all screen sizes */
        body {
            background-color: rgb(0, 128, 66);
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
        }

        .logo {
            width: 100px;
            height: auto;
            margin: 10px;
        }

        .title {
            font-size: 28px;
            text-align: center;
            color: #000;
        }

        .nav {
            margin-top: 20px;
            background-color: #333;
            border-radius: 5px;
            overflow: hidden;
        }

        .nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .nav li {
            padding: 10px 20px;
        }

        .nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .nav a:hover {
            color: #00ff00;
        }

        .main {
            margin-top: 15px;
            width: 100%;
            margin-right: 10px;
        }

        .main form {
            text-align: center;
            margin-bottom: 20px;
        }

        .main input[type="text"] {
            width: 900px;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .main input[type="submit"] {
            background-color: #008041;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .main input[type="submit"]:hover {
            background-color: #006530;
        }

        /* Additional styles for form elements */
        .main legend {
            font-weight: bold;
        }

        .main button:hover {
            background-color: #006530;
        }

        .main table {
            width: 1000px;
            border-collapse: collapse;
            border: 2px solid #ccc;
        }

        .main th, .main td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #ccc;
        }

        .main th {
            background-color: #333;
            color: #fff;
        }

        .main a {
            text-decoration: none;
            color: #00f;
            margin-right: 10px;
        }

        .main a:hover {
            text-decoration: underline;
        }

    </style>
    <title>
        edit students
    </title>
</head>
<body>
<?php
include('init.php'); // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form has been submitted

    // Retrieve the student ID and updated student details from the form
    $student_id = $_POST['id'];
    $updated_first_name = $_POST['updated_first_name'];
    $updated_last_name = $_POST['updated_last_name'];
    $updated_registration_number = $_POST['updated_registration_number'];
    $updated_email = $_POST['updated_email'];
    $updated_class = $_POST['updated_class'];
    $updated_password = $_POST['updated_password'];

    // Sanitize input to prevent SQL injection
    $student_id = mysqli_real_escape_string($conn, $student_id);
    $updated_first_name = mysqli_real_escape_string($conn, $updated_first_name);
    $updated_last_name = mysqli_real_escape_string($conn, $updated_last_name);
    $updated_registration_number = mysqli_real_escape_string($conn, $updated_registration_number);
    $updated_email = mysqli_real_escape_string($conn, $updated_email);
    $updated_class = mysqli_real_escape_string($conn, $updated_class);
    $updated_password = mysqli_real_escape_string($conn, $updated_password);

    // Update student details in the database
    $updateQuery = "UPDATE `student` SET 
                    `FirstName` = '$updated_first_name',
                    `LastName` = '$updated_last_name',
                    `registrationNumber` = '$updated_registration_number',
                    `Email` = '$updated_email',
                    `className` = '$updated_class',
                    `password` = '$updated_password'
                    WHERE `id` = '$student_id'";

    if (mysqli_query($conn, $updateQuery)) {
        // Student details updated successfully
        header("Location: manage_students.php"); // Redirect to the student management page
        exit();
    } else {
        // Error updating student details
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} elseif ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    // Display the form for editing the student details

    $student_id = $_GET['id'];

    // Sanitize input to prevent SQL injection
    $student_id = mysqli_real_escape_string($conn, $student_id);

    // Retrieve the current student details from the database
    $selectQuery = "SELECT `FirstName`, `LastName`, `registrationNumber`, `Email`,`className`, `password` FROM `student` WHERE `id` = '$student_id'";
    $result = mysqli_query($conn, $selectQuery);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $current_first_name = $row['FirstName'];
        $current_last_name = $row['LastName'];
        $current_registration_number = $row['registrationNumber'];
        $current_email = $row['Email'];
        $current_class = $row['className'];
        $current_password = $row['password'];

        // Display the form for editing the student details
        echo "<form method='POST' action='edit_students.php'>
                <input type='hidden' name='id' value='$student_id'>
                First Name: <input type='text' name='updated_first_name' value='$current_first_name'><br>
                Last Name: <input type='text' name='updated_last_name' value='$current_last_name'><br>
                Registration Number: <input type='text' name='updated_registration_number' value='$current_registration_number'><br>
                Email: <input type='text' name='updated_email' value='$current_email'><br>
                Class: <input type='text' name='updated_class' value='$current_class'><br>
                Password: <input type='text' name='updated_password' value='$current_password'><br>
                <input type='submit' value='Update'>
              </form>";
    } else {
        echo "Student not found.";
    }
} else {
    // Invalid request
    echo "Invalid request.";
}
?>
