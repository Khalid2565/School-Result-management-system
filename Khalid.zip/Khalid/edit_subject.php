<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Class</title>
    <link rel="stylesheet" href="./css/home.css">
    <link rel="stylesheet" href="./css/form.css">
    <link rel="stylesheet" href="./css/font-awesome-4.7.0/css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <style>
        /* Common styles for all screen sizes */
        body {
            background-color: rgb(0, 128, 66);
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .container {
            background-color: #fff;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 800px;
        }

        .logo {
            width: 100px;
            height: auto;
            margin: 10px;
        }

        .title {
            font-size: 28px;
            text-align: center;
            color: #000;
        }

        .nav {
            margin-top: 20px;
            background-color: #333;
            border-radius: 5px;
            overflow: hidden;
        }

        .nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
        }

        .nav li {
            padding: 10px 20px;
        }

        .nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .nav a:hover {
            color: #00ff00;
        }

        .main {
            margin-top: 20px;
            width: 100%;
        }

        .main form {
            text-align: center;
            margin-bottom: 20px;
        }

        .main input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .main input[type="submit"] {
            background-color: #008041;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .main input[type="submit"]:hover {
            background-color: #006530;
        }

      
        .main legend {
            font-weight: bold;
        }
        
    </style>
    <title>
        edit subjects
    </title>
</head>
<body>
<?php
include('init.php');
$subject_id = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject_id = $_POST['id'];
    $updated_subject_code = $_POST['updated_subject_code'];
    $updated_subject = $_POST['updated_subject'];

    $subject_id = mysqli_real_escape_string($conn, $subject_id);
    $updated_subject_code = mysqli_real_escape_string($conn, $updated_subject_code);
    $updated_subject = mysqli_real_escape_string($conn, $updated_subject);

    $updateQuery = "UPDATE `subject` SET 
                    `subjectCode` = '$updated_subject_code',
                    `subject` = '$updated_subject'
                    WHERE `id` = '$subject_id'";

    if (mysqli_query($conn, $updateQuery)) {
        header("Location: manage_subjects.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }

    mysqli_close($conn);
} elseif ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $subject_id = $_GET['id'];

    $subject_id = mysqli_real_escape_string($conn, $subject_id);

    $selectQuery = "SELECT `subjectCode`, `subject` FROM `subject` WHERE `id` = '$subject_id'";
    $result = mysqli_query($conn, $selectQuery);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $current_subject_code = $row['subjectCode'];
        $current_subject = $row['subject'];

        echo "<form method='POST' action='edit_subject.php'>
                <input type='hidden' name='id' value='$subject_id'>
                Subject Code: <input type='text' name='updated_subject_code' value='$current_subject_code'><br>
                Subject: <input type='text' name='updated_subject' value='$current_subject'><br>
                <input type='submit' value='Update'>
              </form>";
    } else {
        echo "Subject not found.";
    }
} else {

    echo "Invalid request.";
}
?>
